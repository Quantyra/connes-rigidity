Hypothesis failure for Ioana's Theorem 8.2 under a twisted comultiplication
Daniel Eric Fredriksen — v0.1.3-report — 28 October 2026
LOCAL REVIEW CANDIDATE. Not approved for submission or release.

This archive contains the complete manuscript source, an inline bibliography,
source identity/page anchors and these build instructions. No external figures,
bibliography database, third-party PDFs, private logs or Lean builds are needed.

Files:
  nielsen-ioana-theta-reductio-arxiv.tex
  SOURCE-IDENTITIES.md
  README.txt
  LICENSE.txt

Tested compiler: Tectonic 0.17.0 (TeX reruns managed automatically).
From the extracted directory:
  tectonic --keep-logs nielsen-ioana-theta-reductio-arxiv.tex
The initial run may download standard TeX packages/fonts from Tectonic's bundle.

Alternative conventional build (recipe only, not certified in this revision):
  pdflatex -interaction=nonstopmode -halt-on-error nielsen-ioana-theta-reductio-arxiv.tex
  pdflatex -interaction=nonstopmode -halt-on-error nielsen-ioana-theta-reductio-arxiv.tex
Packages: amsmath, amssymb, amsthm, array, geometry, seqsplit, xurl, hyperref.

The source is UTF-8. Build auxiliary files are not source inputs. PDF metadata
can vary by engine/date; the repository verification manifest identifies the
reviewed PDF and archive bytes. The source bundle is for typesetting this paper,
not for reproducing the companion Lean build or redistributing cited sources.

Historical v0.1.2-report DOI 10.5281/zenodo.21859653 identifies the previous
version, not this candidate. No DOI has been assigned to v0.1.3-report.
Lean v0.1.1-obstruction at c1e6dfb7347261336714e57de86e6f25c7627461
retains its historical identity; independent review of this candidate is pending.
